## ✨ Inventory Management System

Inventory Management System with Laravel 10 and MySql.

![Dashboard](https://user-images.githubusercontent.com/71541409/236858603-89e4be74-0a8b-4b4b-98b0-24e66ec5602d.png)

## 💀 Design Database
![Diagram Class](https://github.com/fajarghifar/inventory-management-system/assets/71541409/0c7d4163-96f5-4724-8741-4615e52ecf98)

## 😎 Features
- POS
- Orders
  - Pending Orders
  - Complete Orders
  - Pending Due
- Purchases
  - All Purchases
  - Approval Purchases
  - Purchase Report
- Products
- Customers
- Suppliers


## 🚀 How to Use

1. **Clone Repository or Download**
    ```bash
    git clone https://github.com/fajarghifar/inventory-management-system
    ```
    
2. **Setup**
    ```bash
    # Go into the repository
    cd inventory-management-system

    # Install dependencies
    composer install

    # Open with your text editor
    code .
    ```
   
3. **.ENV**
    Rename or copy the `.env.example` file to `.env`
    ```bash
    # Generate app key
    php artisan key:generate
    ```
   
4. **Custom Faker Locale**
    To set Faker Locale, add this line of code to the end `.env` file.
    ```bash
    # In this case, the locale is set to Indonesian

    FAKER_LOCALE="id_ID"
    ```

5. **Setup Database**
    Setup your database credentials in your `.env` file.

6. **Seed Database**
    ```bash
    php artisan migrate:fresh --seed
    ```
   *Note: If showing an error, please try to rerun this command.*

7. **Create Storage Link**
    ```bash
    php artisan storage:link
    ```

8. **Run Server**
    ```bash
    php artisan serve
    ```

9. **Login**
    Try login with username: `admin` and password: `password`

## 🚀 Config

1. **Config Chart**

    Open file `./config/cart.php`. You can set a tax, format number, etc.
    > For More details, visit this link [hardevine/shoppingcart](https://packagist.org/packages/hardevine/shoppingcart).

## 📝 Contributing

If you have any ideas to make it more interesting, please send a PR or create an issue for a feature request.

# 🤝 License

### [MIT](LICENSE)

> Github [@fajarghifar](https://github.com/fajarghifar) &nbsp;&middot;&nbsp;
> Instagram [@fajarghifar](https://instagram.com/fajarghifar)
