<footer class="footer-admin mt-auto footer-light">
    <div class="container-xl px-4">
        <div class="row">
            <div class="col-md-6 small">Copyright © Your Website <script>document.write(new Date().getFullYear())</script></div>
            <div class="col-md-6 text-md-end small">
                <a href="#">Privacy Policy</a>
                ·
                <a href="#">Terms &amp; Conditions</a>
            </div>
        </div>
    </div>
</footer>
